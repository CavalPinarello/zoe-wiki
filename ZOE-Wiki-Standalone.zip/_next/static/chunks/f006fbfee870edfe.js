__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/7a4930d8f523458d.js",
  "static/chunks/turbopack-34762d647456dd9c.js"
])
