__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/7a4930d8f523458d.js",
  "static/chunks/turbopack-f440736188cdac00.js"
])
